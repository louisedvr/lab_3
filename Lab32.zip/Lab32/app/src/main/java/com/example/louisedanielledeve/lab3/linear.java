package com.example.louisedanielledeve.lab3;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;


public class linear extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.linear);
    }
}
