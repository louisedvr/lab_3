package com.example.louisedanielledeve.lab3;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class constraint extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.constraint);
    }
}


